=== Ads1K Official Plugin & Integration Tool ===
Contributors: Ads1K
Tags: ads1k.com, ads1k, ads 1k, code, integrator, integration, popunder, pop-under, redirect, script, snippet, tool, website ads, advertising, monetize, monetize website, make money, ads on website, CPM ads, adsense alternative, ads injection, adsense, adserving, advert, advertising, earn, earnings, javascript, monetisation, monetise, monetization, plugin, revenues, traffic, url, wordpress
Requires at least: 3.0.1
Tested up to: 4.5.3
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easy Monetization for WordPress websites, designed to help the integration of the publisher code from Ads1K.Com

== Description ==

Ads1K is one Ad Network built for publishers, featuring an ad serving technology that handles and delivers more than 10MM impressions daily to a select clientele around the world.
This plugin offers the possibility to easy integrate the Ads1K.Com pop-under and redirect code with the option of temporarily disabling the code integration without having to uninstall or deactivate the plugin.

More details here: http://ads1k.com/wordpress_plugin.php

== Installation ==

1. Install the plugin through the WordPress plugins screen directly or upload the plugin files to the "/wp-content/plugins/ads1k-official" directory.
2. Activate the plugin through the 'Plugins' menu screen in WordPress
3. Create an "AccountLess Panel" on Ads1k.com or use the ID/URL string from an existing panel.
4. Configure  the plugin usage for popunder or redirect activities by pasting the ID string into the filed shown.

That's it - Ads1K ads will appear on the website, generating instant earnings.

== Changelog ==

= 1.1 =
* First Version.